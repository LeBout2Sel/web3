# CERIcar

### Students:
#### Labrak Yanis
#### Vougeot Valentin

![Preview](demo/preview.PNG)

### Dependances:

* Doctrine - https://www.doctrine-project.org/
* Boostrap - https://getbootstrap.com/
* JQuery - https://getbootstrap.com/

### Sources:
 
* https://undraw.co/search - Pour les images d'ilustration
* https://www.blablacar.fr/ - Pour deux images