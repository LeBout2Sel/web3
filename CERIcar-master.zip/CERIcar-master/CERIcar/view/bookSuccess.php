<div class="centeredSearch">

<div class="text-center">
    <img src="order_confirmed.svg" style="width: 25em;">
    <h1 class="titleSearch">Réservation confirmer.</h1>
</div>

</div>